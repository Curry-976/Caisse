<?php require_once 'auth.php'; ?>
<?php
require_once __DIR__ . '/auth.php';
admin_require_login();
// change status if posted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_status'])) {
    $id = intval($_POST['id']); $status = $_POST['status'];
    $pdo->prepare('UPDATE commandes SET statut = ? WHERE id = ?')->execute([$status, $id]);
    header('Location: commandes.php'); exit;
}
// if specific id, show details
$show = intval($_GET['id'] ?? 0);
if ($show>0) {
    $stmt = $pdo->prepare('SELECT * FROM commandes WHERE id = ?'); $stmt->execute([$show]); $order = $stmt->fetch();
    $lines = $pdo->prepare('SELECT lc.*, p.nom FROM lignes_commandes lc JOIN produits p ON p.id = lc.produit_id WHERE lc.commande_id = ?'); $lines->execute([$show]); $lines = $lines->fetchAll();
} else {
    $orders = $pdo->query('SELECT * FROM commandes ORDER BY date_commande DESC LIMIT 200')->fetchAll();
}
?>
<!doctype html>
<html lang="fr">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin - Commandes</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
  <a class="btn btn-sm btn-outline-light" href="logout.php">Se déconnecter</a>
<nav class="navbar navbar-expand bg-dark navbar-dark"><div class="container-fluid"><a class="navbar-brand" href="dashboard.php">Admin</a><div class="d-flex"><span class="navbar-text text-white me-3"><?=htmlspecialchars($_SESSION['admin_username'])?></span><a class="btn btn-sm btn-outline-light" href="logout.php">Se déconnecter</a></div></div></nav>
<div class="container my-4">
  <?php if($show>0): ?>
    <a href="commandes.php" class="btn btn-secondary mb-3">← Retour</a>
    <h4>Commande #<?=htmlspecialchars($order['id'])?></h4>
    <p>Date: <?=htmlspecialchars($order['date_commande'])?> — Mode: <?=htmlspecialchars($order['mode_paiement'])?></p>
    <table class="table">
      <?php foreach($lines as $l): ?>
        <tr><td><?=htmlspecialchars($l['nom'])?> x <?=htmlspecialchars($l['quantite'])?></td><td style="text-align:right"><?=number_format($l['prix_unitaire']*$l['quantite'],2,'.','')?> €</td></tr>
      <?php endforeach; ?>
      <tr><td>HT</td><td style="text-align:right"><?=number_format($order['total_ht'],2,'.','')?> €</td></tr>
      <tr><td>TVA</td><td style="text-align:right"><?=number_format($order['total_tva'],2,'.','')?> €</td></tr>
      <tr><td><strong>TTC</strong></td><td style="text-align:right"><strong><?=number_format($order['total_ttc'],2,'.','')?> €</strong></td></tr>
    </table>
    <form method="post" class="mb-3">
      <input type="hidden" name="id" value="<?=htmlspecialchars($order['id'])?>">
      <div class="input-group mb-3">
        <select name="status" class="form-select">
          <option <?= $order['statut']=='En préparation'? 'selected':'' ?>>En préparation</option>
          <option <?= $order['statut']=='Servie'? 'selected':'' ?>>Servie</option>
          <option <?= $order['statut']=='Payée'? 'selected':'' ?>>Payée</option>
        </select>
        <button name="change_status" class="btn btn-primary">Mettre à jour</button>
      </div>
    </form>
    <a class="btn btn-outline-primary" href="../receipt.php?id=<?=htmlspecialchars($order['id'])?>" target="_blank">Voir le ticket</a>
  <?php else: ?>
    <h3>Commandes</h3>
    <table class="table table-striped">
      <thead><tr><th>ID</th><th>Date</th><th>TTC</th><th>Mode</th><th>Statut</th><th></th></tr></thead>
      <tbody>
        <?php foreach($orders as $o): ?>
          <tr>
            <td><?=htmlspecialchars($o['id'])?></td>
            <td><?=htmlspecialchars($o['date_commande'])?></td>
            <td><?=number_format($o['total_ttc'],2,'.','')?> €</td>
            <td><?=htmlspecialchars($o['mode_paiement'])?></td>
            <td><?=htmlspecialchars($o['statut'])?></td>
            <td><a class="btn btn-sm btn-primary" href="commandes.php?id=<?=htmlspecialchars($o['id'])?>">Voir</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
</body></html>
