<?php
// admin/register.php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_validate()) {
        $error = "Session expirée. Réessaie.";
    } else {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        if ($username === '' || $password === '' || strlen($password) < 6) {
            $error = 'Remplis tous les champs (mdp ≥ 6).';
        } else {
            // vérifier unicité
            $exists = $pdo->prepare("SELECT 1 FROM admins WHERE username = ?");
            $exists->execute([$username]);
            if ($exists->fetchColumn()) {
                $error = "Nom d’utilisateur déjà pris.";
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $ins = $pdo->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
                $ins->execute([$username, $hash]);
                header('Location: login.php');
                exit;
            }
        }
    }
}
?><!doctype html>
<html lang="fr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin - Inscription</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light">
<div class="container py-5" style="max-width:420px;">
  <div class="card shadow-sm">
    <div class="card-body">
      <h1 class="h4 mb-3">Admin — Inscription</h1>
      <?php if ($error): ?><div class="alert alert-danger py-2"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
      <form method="post" action="">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label class="form-label">Nom d’utilisateur</label>
          <input name="username" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Mot de passe</label>
          <input type="password" name="password" class="form-control" required minlength="6">
        </div>
        <button class="btn btn-primary w-100" type="submit">Créer le compte</button>
      </form>
      <div class="text-center mt-3">
        <a href="login.php">Se connecter</a>
      </div>
    </div>
  </div>
</div>
</body></html>
