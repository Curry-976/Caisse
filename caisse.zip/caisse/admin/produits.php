<?php
// admin/produits.php
require_once __DIR__ . '/auth.php';
admin_require_login();

// Suppression via POST + CSRF
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    if (!csrf_validate()) { http_response_code(419); exit('CSRF'); }
    $id = (int)$_POST['delete_id'];
    if ($id > 0) {
        $pdo->prepare('DELETE FROM produits WHERE id = ?')->execute([$id]);
    }
    header('Location: produits.php'); exit;
}

// Liste produits
$products = $pdo->query('SELECT * FROM produits ORDER BY categorie, nom')->fetchAll();
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin - Produits</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">

  <!-- Entête + Boutons -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4">Produits</h1>
    <div>
      <a class="btn btn-primary me-2" href="produit_ajouter.php">Ajouter un produit</a>
      <a class="btn btn-secondary me-2" href="dashboard.php">Dashboard</a>
      <a class="btn btn-outline-danger" href="logout.php">Déconnexion</a>
    </div>
  </div>

  <!-- Tableau produits -->
  <table class="table table-sm table-striped align-middle">
    <thead>
      <tr>
        <th>Nom</th>
        <th>Catégorie</th>
        <th class="text-end">Prix</th>
        <th class="text-end">TVA %</th>
        <th class="text-end">Stock</th>
        <th class="text-end">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($products as $p): ?>
      <tr>
        <td><?php echo htmlspecialchars($p['nom'], ENT_QUOTES, 'UTF-8'); ?></td>
        <td><?php echo htmlspecialchars($p['categorie'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
        <td class="text-end"><?php echo number_format((float)$p['prix'], 2, ',', ' '); ?> €</td>
        <td class="text-end"><?php echo number_format((float)$p['taux_tva'], 2, ',', ' '); ?></td>
        <td class="text-end"><?php echo (int)($p['stock'] ?? 0); ?></td>
        <td class="text-end">
          <!-- Bouton Modifier -->
          <a class="btn btn-sm btn-warning me-1" href="produit_modifier.php?id=<?php echo (int)$p['id']; ?>">Modifier</a>

          <!-- Bouton Supprimer -->
          <form method="post" class="d-inline" onsubmit="return confirm('Supprimer ce produit ?');">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="delete_id" value="<?php echo (int)$p['id']; ?>">
            <button class="btn btn-sm btn-danger">Supprimer</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

</div>
</body>
</html>
