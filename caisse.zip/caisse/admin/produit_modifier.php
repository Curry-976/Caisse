<?php
require_once __DIR__ . '/auth.php';
admin_require_login();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { header('Location: produits.php'); exit; }

$stmt = $pdo->prepare("SELECT * FROM produits WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();
if (!$product) { header('Location: produits.php'); exit; }

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_validate()) { http_response_code(419); exit('CSRF'); }

    $nom = trim($_POST['nom'] ?? '');
    $categorie = trim($_POST['categorie'] ?? '');
    $prix = (float)($_POST['prix'] ?? 0);
    $taux_tva = (float)($_POST['taux_tva'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);

    if ($nom === '') $errors[] = 'Le nom est obligatoire.';

    if (!$errors) {
        $stmt = $pdo->prepare("UPDATE produits SET nom=?, categorie=?, prix=?, taux_tva=?, stock=? WHERE id=?");
        $stmt->execute([$nom, $categorie, $prix, $taux_tva, $stock, $id]);
        header('Location: produits.php'); exit;
    }
}
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Modifier un produit</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
<h1 class="h4 mb-3">Modifier le produit</h1>

<?php if ($errors): ?>
<div class="alert alert-danger"><?php echo implode('<br>', $errors); ?></div>
<?php endif; ?>

<form method="post">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label class="form-label">Nom</label>
    <input type="text" name="nom" class="form-control" value="<?php echo htmlspecialchars($product['nom'], ENT_QUOTES); ?>" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Catégorie</label>
    <input type="text" name="categorie" class="form-control" value="<?php echo htmlspecialchars($product['categorie'] ?? '', ENT_QUOTES); ?>">
  </div>
  <div class="mb-3">
    <label class="form-label">Prix (€)</label>
    <input type="number" step="0.01" name="prix" class="form-control" value="<?php echo htmlspecialchars($product['prix'], ENT_QUOTES); ?>">
  </div>
  <div class="mb-3">
    <label class="form-label">TVA (%)</label>
    <input type="number" step="0.01" name="taux_tva" class="form-control" value="<?php echo htmlspecialchars($product['taux_tva'], ENT_QUOTES); ?>">
  </div>
  <div class="mb-3">
    <label class="form-label">Stock</label>
    <input type="number" name="stock" class="form-control" value="<?php echo (int)$product['stock']; ?>">
  </div>
  <button class="btn btn-warning">Modifier</button>
  <a class="btn btn-secondary" href="produits.php">Annuler</a>
</form>
</div>
</body>
</html>