<?php
// admin/login.php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

if (!empty($_SESSION['admin_logged'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_validate()) {
        $error = "Session expirée. Réessaie.";
    } else {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');

        if ($username === '' || $password === '') {
            $error = 'Identifiants requis';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
            $stmt->execute([$username]);
            $admin = $stmt->fetch();
            if ($admin && password_verify($password, $admin['password'])) {
                admin_login($admin);
                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'Nom d’utilisateur ou mot de passe invalide';
            }
        }
    }
}
?><!doctype html>
<html lang="fr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin - Connexion</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light">
<div class="container py-5" style="max-width:420px;">
  <div class="card shadow-sm">
    <div class="card-body">
      <h1 class="h4 mb-3">Admin — Connexion</h1>
      <?php if ($error): ?><div class="alert alert-danger py-2"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
      <form method="post" action="">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label class="form-label">Nom d’utilisateur</label>
          <input name="username" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Mot de passe</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <button class="btn btn-primary w-100" type="submit">Se connecter</button>
      </form>
      <div class="text-center mt-3">
        <a href="register.php">Créer un compte</a>
      </div>
    </div>
  </div>
</div>
</body></html>
