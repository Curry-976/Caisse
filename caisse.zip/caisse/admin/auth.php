<?php
// admin/auth.php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/db.php';

function admin_require_login(): void {
    if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
        header('Location: login.php');
        exit;
    }
}

function admin_login(array $user): void {
    // Sécurise la session à la connexion
    session_regenerate_id(true);
    $_SESSION['admin_logged']   = true;
    $_SESSION['admin_id']       = (int)$user['id'];
    $_SESSION['admin_username'] = (string)$user['username'];
}

function admin_logout(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params['path'], $params['domain'],
            $params['secure'], $params['httponly']
        );
    }
    session_destroy();
    session_regenerate_id(true);
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    $t = htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8');
    return '<input type="hidden" name="csrf" value="' . $t . '">';
}

function csrf_validate(): bool {
    $posted = $_POST['csrf'] ?? '';
    return is_string($posted) && hash_equals($_SESSION['csrf'] ?? '', $posted);
}
