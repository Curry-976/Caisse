<?php require_once 'auth.php'; ?>
<?php
require_once __DIR__ . '/auth.php';
admin_require_login();
$todayStart = date('Y-m-d') . ' 00:00:00';
$todayEnd = date('Y-m-d') . ' 23:59:59';
$stmt = $pdo->prepare('SELECT COUNT(*) as nb, COALESCE(SUM(total_ttc),0) as ca FROM commandes WHERE date_commande BETWEEN ? AND ?');
$stmt->execute([$todayStart, $todayEnd]);
$today = $stmt->fetch();
$recent = $pdo->query('SELECT * FROM commandes ORDER BY date_commande DESC LIMIT 8')->fetchAll();
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Admin - Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <a class="btn btn-sm btn-outline-light" href="logout.php">Se déconnecter</a>
<nav class="navbar navbar-expand bg-dark navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">Admin</a>
    <div class="d-flex">
      <span class="navbar-text text-white me-3"><?=htmlspecialchars($_SESSION['admin_username'])?></span>
      <a class="btn btn-sm btn-outline-light" href="logout.php">Se déconnecter</a>
    </div>
  </div>
</nav>
<div class="container my-4">
  <div class="row g-3">
    <div class="col-md-4">
      <div class="card p-3">
        <h6>Commandes aujourd'hui</h6>
        <div class="display-6"><?=htmlspecialchars($today['nb'])?></div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card p-3">
        <h6>CA aujourd'hui</h6>
        <div class="display-6"><?=number_format($today['ca'],2,'.','')?> €</div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card p-3">
        <h6>Produits</h6>
        <div class="display-6"><?= $pdo->query('SELECT COUNT(*) FROM produits')->fetchColumn(); ?> </div>
      </div>
    </div>
  </div>

  <div class="mt-4">
    <h5>Dernières commandes</h5>
    <table class="table table-striped">
      <thead><tr><th>ID</th><th>Date</th><th>TTC</th><th>Mode</th><th>Statut</th><th></th></tr></thead>
      <tbody>
      <?php foreach($recent as $r): ?>
        <tr>
          <td><?=htmlspecialchars($r['id'])?></td>
          <td><?=htmlspecialchars($r['date_commande'])?></td>
          <td><?=number_format($r['total_ttc'],2,'.','')?> €</td>
          <td><?=htmlspecialchars($r['mode_paiement'])?></td>
          <td><?=htmlspecialchars($r['statut'])?></td>
          <td><a class="btn btn-sm btn-primary" href="commandes.php?id=<?=htmlspecialchars($r['id'])?>">Voir</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div class="mt-4">
    <a class="btn btn-secondary" href="produits.php">Gérer les produits</a>
    <a class="btn btn-secondary" href="commandes.php">Gérer les commandes</a>
    <a class="btn btn-secondary" href="stats.php">Statistiques détaillées</a>
  </div>
</div>
</body>
</html>

