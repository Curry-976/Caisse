<?php require_once 'auth.php'; ?>
<?php
require_once __DIR__ . '/auth.php';
admin_require_login();
$id = intval($_GET['id'] ?? 0);
if ($id>0) {
    $pdo->prepare('DELETE FROM produits WHERE id = ?')->execute([$id]);
}
header('Location: produits.php');
exit;
