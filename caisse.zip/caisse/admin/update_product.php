<?php require_once 'auth.php'; ?>
<?php
require_once __DIR__ . '/auth.php';
admin_require_login();
$id = intval($_GET['id'] ?? 0);
if ($id <= 0) { header('Location: produits.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = $_POST['nom'] ?? ''; $categorie = $_POST['categorie'] ?? ''; $prix = floatval($_POST['prix']); $tva = floatval($_POST['tva']); $stock = intval($_POST['stock']);
    $stmt = $pdo->prepare('UPDATE produits SET nom=?, categorie=?, prix=?, taux_tva=?, stock=? WHERE id=?');
    $stmt->execute([$nom, $categorie, $prix, $tva, $stock, $id]);
    header('Location: produits.php'); exit;
}
$stmt = $pdo->prepare('SELECT * FROM produits WHERE id=?'); $stmt->execute([$id]); $p = $stmt->fetch();
if (!$p) { header('Location: produits.php'); exit; }
?>
<!doctype html>
<html lang="fr">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Éditer produit</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light">
  <a class="btn btn-sm btn-outline-light" href="logout.php">Se déconnecter</a>
<div class="container py-4">
  <a href="produits.php" class="btn btn-secondary mb-3">← Retour</a>
  <div class="card">
    <div class="card-body">
      <h4>Éditer produit #<?=htmlspecialchars($p['id'])?></h4>
      <form method="post">
        <div class="mb-3"><label>Nom</label><input name="nom" class="form-control" required value="<?=htmlspecialchars($p['nom'])?>"></div>
        <div class="mb-3"><label>Catégorie</label><input name="categorie" class="form-control" value="<?=htmlspecialchars($p['categorie'])?>"></div>
        <div class="mb-3"><label>Prix</label><input name="prix" type="number" step="0.01" class="form-control" required value="<?=htmlspecialchars($p['prix'])?>"></div>
        <div class="mb-3"><label>TVA (%)</label><input name="tva" type="number" step="0.01" class="form-control" value="<?=htmlspecialchars($p['taux_tva'])?>"></div>
        <div class="mb-3"><label>Stock</label><input name="stock" type="number" class="form-control" value="<?=htmlspecialchars($p['stock'])?>"></div>
        <button class="btn btn-primary">Enregistrer</button>
      </form>
    </div>
  </div>
</div>
</body>
</html>
