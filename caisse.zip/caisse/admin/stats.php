<?php require_once 'auth.php'; ?>
<?php
require_once __DIR__ . '/auth.php';
admin_require_login();
// prepare data: sales for last 30 days
$days = 30;
$labels = []; $values = [];
for ($i = $days-1; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $labels[] = $date;
    $stmt = $pdo->prepare('SELECT COALESCE(SUM(total_ttc),0) as ca FROM commandes WHERE DATE(date_commande)=?');
    $stmt->execute([$date]);
    $row = $stmt->fetch();
    $values[] = (float)$row['ca'];
}
// summary numbers
$today = $pdo->prepare('SELECT COUNT(*) as nb, COALESCE(SUM(total_ttc),0) as ca FROM commandes WHERE DATE(date_commande)=?');
$today->execute([date('Y-m-d')]); $today = $today->fetch();
$thisMonth = $pdo->prepare('SELECT COUNT(*) as nb, COALESCE(SUM(total_ttc),0) as ca FROM commandes WHERE MONTH(date_commande)=MONTH(CURDATE()) AND YEAR(date_commande)=YEAR(CURDATE())');
$thisMonth->execute(); $thisMonth = $thisMonth->fetch();
$thisWeek = $pdo->prepare('SELECT COUNT(*) as nb, COALESCE(SUM(total_ttc),0) as ca FROM commandes WHERE YEARWEEK(date_commande,1)=YEARWEEK(CURDATE(),1)');
$thisWeek->execute(); $thisWeek = $thisWeek->fetch();
?>
<!doctype html>
<html lang="fr">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin - Statistiques</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
  <a class="btn btn-sm btn-outline-light" href="logout.php">Se déconnecter</a>
<nav class="navbar navbar-expand bg-dark navbar-dark"><div class="container-fluid"><a class="navbar-brand" href="dashboard.php">Admin</a><div class="d-flex"><span class="navbar-text text-white me-3"><?=htmlspecialchars($_SESSION['admin_username'])?></span><a class="btn btn-sm btn-outline-light" href="logout.php">Se déconnecter</a></div></div></nav>
<div class="container my-4">
  <h3>Statistiques</h3>
  <div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card p-3"><small>Ventes aujourd'hui</small><div class="h4"><?=htmlspecialchars($today['nb'])?></div><div><?=number_format($today['ca'],2,'.','')?> €</div></div></div>
    <div class="col-md-3"><div class="card p-3"><small>Ventes cette semaine</small><div class="h4"><?=htmlspecialchars($thisWeek['nb'])?></div><div><?=number_format($thisWeek['ca'],2,'.','')?> €</div></div></div>
    <div class="col-md-3"><div class="card p-3"><small>Ventes ce mois</small><div class="h4"><?=htmlspecialchars($thisMonth['nb'])?></div><div><?=number_format($thisMonth['ca'],2,'.','')?> €</div></div></div>
    <div class="col-md-3"><div class="card p-3"><small>Total produits</small><div class="h4"><?= $pdo->query('SELECT COUNT(*) FROM produits')->fetchColumn(); ?></div></div></div>
  </div>

  <div class="card p-3 mb-4">
    <h5>Évolution (30 derniers jours)</h5>
    <canvas id="chart"></canvas>
  </div>

  <div>
    <a class="btn btn-secondary" href="dashboard.php">Retour</a>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  const labels = <?php echo json_encode($labels); ?>;
  const data = <?php echo json_encode($values); ?>;
  const ctx = document.getElementById('chart').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'CA (TTC)',
        data: data,
        fill: true,
        tension: 0.3,
        borderWidth: 2
      }]
    },
    options: {
      scales: {
        y: { beginAtZero: true }
      }
    }
  });
</script>
</body></html>
