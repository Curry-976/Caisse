<?php
// api/save_order.php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json; charset=utf-8');

$payload = json_decode(file_get_contents('php://input'), true);
if (!$payload || empty($payload['items']) || !is_array($payload['items'])) {
    http_response_code(400);
    exit(json_encode(['error'=>'Données invalides']));
}

$mode = in_array(($payload['mode'] ?? 'Especes'), ['Especes','Carte'], true) ? $payload['mode'] : 'Especes';

// Récupérer IDs
$ids = array_values(array_unique(array_map(fn($it)=> (int)($it['id'] ?? 0), $payload['items'])));
if (!$ids) { http_response_code(400); exit(json_encode(['error'=>'Aucun produit'])); }

$in  = implode(',', array_fill(0, count($ids), '?'));
$stmt = $pdo->prepare("SELECT id, nom, prix, taux_tva, stock FROM produits WHERE id IN ($in)");
$stmt->execute($ids);
$map = [];
foreach ($stmt->fetchAll() as $p) $map[(int)$p['id']] = $p;

$total_ht = $total_tva = $total_ttc = 0.0;
$lines = [];
foreach ($payload['items'] as $it) {
    $pid = (int)($it['id'] ?? 0);
    $qty = max(0, (int)($it['qty'] ?? 0));
    if ($qty < 1 || !isset($map[$pid])) continue;

    $p = $map[$pid];
    // vérifier stock si non null
    if ($p['stock'] !== null && (int)$p['stock'] < $qty) {
        http_response_code(409);
        exit(json_encode(['error'=>"Stock insuffisant pour {$p['nom']}"]));
    }

    $prix = (float)$p['prix'];
    $tva_rate = (float)$p['taux_tva'];
    $ht  = $prix * $qty;
    $tva = round($ht * ($tva_rate/100), 2);
    $ttc = round($ht + $tva, 2);

    $total_ht  += $ht;
    $total_tva += $tva;
    $total_ttc += $ttc;

    $lines[] = ['id'=>$pid,'nom'=>$p['nom'],'qty'=>$qty,'prix'=>$prix,'tva'=>$tva];
}

if (!$lines) { http_response_code(400); exit(json_encode(['error'=>'Panier vide'])); }

try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO commandes (date_commande, mode_paiement, total_ht, total_tva, total_ttc, statut)
                           VALUES (NOW(), ?, ?, ?, ?, 'PAYEE')");
    $stmt->execute([$mode, $total_ht, $total_tva, $total_ttc]);
    $commande_id = (int)$pdo->lastInsertId();

    $ins = $pdo->prepare("INSERT INTO lignes_commandes (commande_id, produit_id, quantite, prix_unitaire, tva_ligne)
                          VALUES (?, ?, ?, ?, ?)");
    foreach ($lines as $L) {
        $ins->execute([$commande_id, $L['id'], $L['qty'], $L['prix'], $L['tva']]);
        // décrément stock
        $pdo->prepare("UPDATE produits SET stock = stock - ? WHERE id = ?")->execute([$L['qty'], $L['id']]);
    }

    $pdo->commit();
    echo json_encode(['success'=>true, 'commande_id'=>$commande_id, 'total'=>$total_ttc]);
} catch (Throwable $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error'=>'Erreur enregistrement']);
}
