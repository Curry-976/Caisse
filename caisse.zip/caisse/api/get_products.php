<?php
// api/get_products.php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json; charset=utf-8');

try {
    $stmt = $pdo->query('SELECT id, nom, prix, categorie, taux_tva, stock FROM produits ORDER BY categorie, nom');
    $products = $stmt->fetchAll();
    echo json_encode($products, JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur serveur']);
}
