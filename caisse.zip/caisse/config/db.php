<?php
// config/db.php
declare(strict_types=1);

// Ajuste ces valeurs selon ton environnement
$dbHost = '127.0.0.1';     // hôte MySQL
$dbName = 'caisse_restaurant';
$dbUser = 'root';
$dbPass = '';
$dbPort = 3306;            // 3306 par défaut pour MySQL

$dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Erreur connexion DB.');
}
