<?php
// public/receipt.php
declare(strict_types=1);
require_once __DIR__ . '/../config/db.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(400); exit('Commande invalide'); }

$cmd = $pdo->prepare("SELECT * FROM commandes WHERE id = ?");
$cmd->execute([$id]);
$commande = $cmd->fetch();
if (!$commande) { http_response_code(404); exit('Commande introuvable'); }

$lines = $pdo->prepare("SELECT lc.*, p.nom FROM lignes_commandes lc JOIN produits p ON p.id = lc.produit_id WHERE lc.commande_id = ?");
$lines->execute([$id]);
$rows = $lines->fetchAll();
?><!doctype html>
<html lang="fr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reçu #<?php echo (int)$id; ?></title>
<style>
body{font-family:system-ui,Arial;margin:20px}
h1{font-size:18px;margin:0 0 10px}
table{width:100%;border-collapse:collapse;margin-top:10px}
th,td{border-bottom:1px solid #eee;padding:6px;text-align:left}
tfoot td{font-weight:bold}
.small{color:#666;font-size:12px}
.print{margin:10px 0}
</style>
</head><body>
<h1>Reçu — Commande #<?php echo (int)$id; ?></h1>
<div class="small">
  Date : <?php echo htmlspecialchars($commande['date_commande'] ?? '', ENT_QUOTES, 'UTF-8'); ?> —
  Paiement : <?php echo htmlspecialchars($commande['mode_paiement'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
</div>

<table>
  <thead><tr><th>Article</th><th>Qté</th><th>PU</th><th>TVA</th></tr></thead>
  <tbody>
    <?php foreach($rows as $r): ?>
    <tr>
      <td><?php echo htmlspecialchars($r['nom'], ENT_QUOTES, 'UTF-8'); ?></td>
      <td><?php echo (int)$r['quantite']; ?></td>
      <td><?php echo number_format((float)$r['prix_unitaire'], 2, ',', ' '); ?> €</td>
      <td><?php echo number_format((float)$r['tva_ligne'], 2, ',', ' '); ?> €</td>
    </tr>
    <?php endforeach; ?>
  </tbody>
  <tfoot>
    <tr><td colspan="3">Total HT</td><td><?php echo number_format((float)$commande['total_ht'], 2, ',', ' '); ?> €</td></tr>
    <tr><td colspan="3">TVA</td><td><?php echo number_format((float)$commande['total_tva'], 2, ',', ' '); ?> €</td></tr>
    <tr><td colspan="3">Total TTC</td><td><?php echo number_format((float)$commande['total_ttc'], 2, ',', ' '); ?> €</td></tr>
  </tfoot>
</table>

<div class="print"><button onclick="window.print()">Imprimer</button></div>
</body></html>
