<?php
// public/index.php
?><!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Caisse - Restaurant</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="app">
<header>
  <h1>Caisse - Restaurant</h1>
</header>
<main>
  <section class="left">
    <input id="search" type="search" placeholder="Rechercher un produit..." />
    <div id="products" class="products-grid"></div>
  </section>
  <aside class="right">
    <div class="cart">
      <h2>Panier</h2>
      <div id="cart-items"></div>
      <div class="totals">
        <div>Sous-total HT : <strong id="total-ht">0.00</strong> €</div>
        <div>TVA : <strong id="total-tva">0.00</strong> €</div>
        <div>Total TTC : <strong id="total-ttc">0.00</strong> €</div>
      </div>
      <div class="payment">''
        <label>Mode de paiement</label>
        <select id="mode">
          <option>Especes</option>
          <option>Carte</option>
        </select>
        <div class="cash" id="cash-fields" style="margin-top:8px;display:none;">
          <label>Montant reçu (€)</label>
          <input id="cash-given" type="number" step="0.01" placeholder="0.00">
          <div>Monnaie à rendre : <strong id="cash-change">0.00</strong> €</div>
        </div>
        <button id="payBtn">Valider et enregistrer</button>
      </div>
    </div>
  </aside>
</main>
</div>
<script src="assets/app.js"></script>
</body>
</html>
