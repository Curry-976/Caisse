let products = [];
let cart = [];

function money(x){ return Number.parseFloat(x).toFixed(2); }

async function loadProducts(){
  const res = await fetch('../api/get_products.php');
  const data = await res.json();
  products = Array.isArray(data) ? data : [];
  renderProducts(products);
}

function renderProducts(list){
  const el = document.getElementById('products');
  el.innerHTML = '';
  list.forEach(p => {
    const div = document.createElement('div');
    div.className = 'product';
    div.innerHTML = `
      <h3>${p.nom}</h3>
      <p>${money(p.prix)} € TTC</p>
      <button>Ajouter</button>
    `;
    div.querySelector('button').addEventListener('click', () => addToCart(p.id));
    el.appendChild(div);
  });
}

function addToCart(id){
  const p = products.find(x => x.id == id);
  if(!p) return;
  const line = cart.find(x => x.id == id);
  if(line){ line.qty += 1; }
  else { cart.push({ id: p.id, qty: 1 }); } // on ne stocke pas les prix dans le panier (sécurité)
  renderCart(); resetCash();
}

function removeFromCart(id){
  cart = cart.filter(x => x.id != id);
  renderCart(); resetCash();
}

function changeQty(id, delta){
  const line = cart.find(x => x.id == id);
  if(!line) return;
  line.qty = Math.max(1, line.qty + delta);
  renderCart(); resetCash();
}

function totalsServerSim(){
  // front : estimation uniquement, basée sur produits chargés
  let ht=0, tva=0, ttc=0;
  cart.forEach(it => {
    const p = products.find(x => x.id == it.id);
    if(!p) return;
    const q = it.qty;
    const prix = parseFloat(p.prix);
    const tvaRate = parseFloat(p.taux_tva);
    const lineHt = prix * q;
    const lineTva = Math.round((lineHt * (tvaRate/100))*100)/100;
    ht += lineHt; tva += lineTva; ttc += (lineHt + lineTva);
  });
  return {ht, tva, ttc};
}

function renderCart(){
  const el = document.getElementById('cart-items');
  el.innerHTML = '';
  cart.forEach(it => {
    const p = products.find(x => x.id == it.id);
    if(!p) return;
    const row = document.createElement('div');
    row.className = 'cart-line';
    row.innerHTML = `
      <span>${p.nom}</span>
      <div>
        <button onclick="changeQty(${p.id}, -1)">-</button>
        <strong>${it.qty}</strong>
        <button onclick="changeQty(${p.id}, 1)">+</button>
      </div>
      <button onclick="removeFromCart(${p.id})">Suppr</button>
    `;
    el.appendChild(row);
  });
  const t = totalsServerSim();
  document.getElementById('total-ht').textContent = money(t.ht);
  document.getElementById('total-tva').textContent = money(t.tva);
  document.getElementById('total-ttc').textContent = money(t.ttc);
}

async function pay(){
  if(cart.length === 0) return alert('Panier vide');
  const mode = document.getElementById('mode').value || 'Especes';
  // On n’envoie au serveur que id + qty (les prix seront recalculés côté serveur)
  const payload = { items: cart.map(x => ({ id: x.id, qty: x.qty })), mode };
  const res = await fetch('../api/save_order.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  const data = await res.json();
  if(data.success){
    alert('Commande enregistrée — ID: '+data.commande_id);
    window.open('receipt.php?id='+data.commande_id,'_blank');
    cart = [];
    renderCart(); resetCash();
  } else {
    alert('Erreur: '+(data.error||'erreur serveur'));
  }
}

document.getElementById('payBtn')?.addEventListener('click', pay);
document.getElementById('search')?.addEventListener('input', function(e){
  const q = (e.target.value || '').toLowerCase();
  renderProducts(products.filter(p => (p.nom||'').toLowerCase().includes(q) || (p.categorie||'').toLowerCase().includes(q)));
});


// Gestion de la monnaie rendue
const modeSelect = document.getElementById('mode');
const cashFields = document.getElementById('cash-fields');
const inputGiven = document.getElementById('cash-given');
const changeEl = document.getElementById('cash-change');

function updateCashFields(){
  if(modeSelect.value === 'Especes'){
    cashFields.style.display = 'block';
  } else {
    cashFields.style.display = 'none';
  }
  updateChange();
}

function updateChange(){
  const given = parseFloat(inputGiven.value || 0);
  const total = parseFloat(document.getElementById('total-ttc').textContent || 0);
  const change = given - total;
  changeEl.textContent = money(change > 0 ? change : 0);
}

modeSelect?.addEventListener('change', updateCashFields);
inputGiven?.addEventListener('input', updateChange);

function resetCash(){
  inputGiven.value = '';
  changeEl.textContent = '0.00';
  updateCashFields();
}

updateCashFields();

window.addEventListener('load', loadProducts);
window.resetCash = resetCash;
window.changeQty = changeQty; // expose pour boutons inline
window.removeFromCart = removeFromCart;
